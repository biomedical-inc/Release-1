from socketIO_client import socketIO
import time
import ast
## Connection a la base de donnee
#!/usr/bin/env python3
#import sqlite3

## Connection a la base de donnee
cnx = mysql.connector.connect(user='root', password='', host='127.0.0.1', database='bdd_biomedical')
cursor = cnx.cursor()

#con = sqlite3.connect("devoir1.db")
#cursor = con.cursor()
## Deleguees
def on_connect():
	print('connect')
def on_disconnect():
	print('disconnect')
def on_reconnect():
	print('reconnect')

## Code execute lorsqu'on a une nouvelle connection
def nouveau_client(*args):
	chaine = str(args)
	chaine = chaine[1 : len(chaine) - 2]
	a = ast.literal_eval(chaine)
	cursor.execute("Select idClient from tblClient where identifiant ='" + a['user'] + "' and identifiant ='" + a['pw'] + "';")
	myresult = cursor.fetchone()
	print(myresult)
	
#socketIO.emit('clientId', myresult)

## 'main'
socketIO = SocketIO('localhost', 8080)
socketIO.on('connect', on_connect)
socketIO.on('disconnect', on_disconnect)
socketIO.on('reconnect', on_reconnect)
socketIO.on('nouveau_client', nouveau_client)
## Loop principal
socketIO.wait()
## On fait le menage
cursor.close()


## On fait le menage
con.close()
#cnx.close()
