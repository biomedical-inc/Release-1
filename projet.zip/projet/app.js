var app = require('express')(),
    server = require('http').createServer(app),
    io = require('socket.io').listen(server),
    ent = require('ent'), // Permet de bloquer les caractères HTML (sécurité équivalente à htmlentities en PHP)
    fs = require('fs');

	app.use('/Styles', require('express').static('Styles'));
	app.use('/Images', require('express').static('Images'));
	app.use('/JavaScript', require('express').static('JavaScript'));

// Chargement des pages html
app.get('/', function (req, res) {
  res.sendfile(__dirname + '/index.html');
});

app.get('/admin', function (req, res) {
  res.sendfile(__dirname + '/admin.html');
});

app.get('/consultation', function (req, res) {
  res.sendfile(__dirname + '/consultation.html');
});

var mysql = require('mysql');

io.sockets.on('connection', function (socket) {

    socket.on('nouveau_client', function (data) {
        //message = ent.encode(message);
		//console.log(data.user, " " + data.pw);
		var con = mysql.createConnection({
		  host: "localhost",
		  user: "root",
		  password: "",
		  database: "bdd_biomedicale"
		});

		con.connect(function(err) {
		  if (err) throw err;
		  console.log("Connected!");
		  con.query("SELECT idClient, type FROM tblclient where identifiant = '" + data.user + "' and passwd = '" + data.pw + "'", 
			  function (err, result, fields) {
					if (err){
						socket.emit('redirect', '/');
						throw err;
						console.log(result);
					}
					if(result[0].type == "admin")
						socket.emit('redirect', '/admin');
					else
						socket.emit('redirect', '/consultation');
					//window.location.replace("admin.html");
			  });
		});
    }); 
});

server.listen(8080);
