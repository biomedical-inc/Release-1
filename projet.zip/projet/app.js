var app = require('express')(),
    server = require('http').createServer(app),
    io = require('socket.io').listen(server),
    ent = require('ent'), // Permet de bloquer les caractères HTML (sécurité équivalente à htmlentities en PHP)
    fs = require('fs');
	//var express = require('express');
	//var app2 = express();
	app.use('/Styles', require('express').static('Styles'));
	app.use('/Images', require('express').static('Images'));
	app.use('/JavaScript', require('express').static('JavaScript'));

// Chargement de la page index.html
app.get('/', function (req, res) {
  res.sendfile(__dirname + '/index.html');
});

app.get('/etudiant', function (req, res) {
  res.sendfile(__dirname + '/etudiant.html');
});


io.sockets.on('connection', function (socket) {

    socket.on('nouveau_client', function (data) {
        //message = ent.encode(message);
		//console.log(data.user, " " + data.pw);
        socket.broadcast.emit('nouveau_client', {user: data.user, pw: data.pw});
    }); 
});

server.listen(8080);
