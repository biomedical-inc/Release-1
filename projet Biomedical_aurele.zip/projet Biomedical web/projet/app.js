var app = require('express')(),
    server = require('http').createServer(app),
    io = require('socket.io').listen(server),
    ent = require('ent'), // Permet de bloquer les caractères HTML (sécurité équivalente à htmlentities en PHP)
    fs = require('fs');

	 app.use('/img', require('express').static('img'));
  app.use('/css', require('express').static('css'));
  app.use('/css', require('express').static(__dirname + '/node_modules/bootstrap/dist/css'));
io.conectAdmin= "disc";
io.conectClient= "disc";
// Chargement des pages html
app.get('/', function (req, res) {
  res.sendfile(__dirname + '/index.html');
});

app.get('/admin', function (req, res) {
	if(io.conectAdmin === "con")
  res.sendfile(__dirname + '/admin.html');
  else  res.sendfile(__dirname + '/index.html');
});

app.get('/consultation', function (req, res) {
	if(io.conectClient === "con")
  res.sendfile(__dirname + '/consultation.html');
   else  res.sendfile(__dirname + '/index.html');
});

var mysql = require('mysql');

io.sockets.on('connection', function (socket) {
	
    socket.on('nouveau_client', function (data) {
        //message = ent.encode(message);
		//console.log(data.user, " " + data.pw);
		var con = mysql.createConnection({
		  host: "localhost",
		  user: "root",
		  password: "",
		  database: "dbbiomedicale"
		  
		 
		});
		
		
		con.connect(function(err) {
		  if (err) throw err;
		  console.log("Connected!");
		  con.query("SELECT idClient, types FROM tblclient where identifiant = '" + data.user + "' and passwd = '" + data.pw + "'", 
			  function (err, result, fields) {
					if (err){
						
						throw err;
						
					}
					
					if(result.length != 0){				
						
						if(result[0].types === "admin"){
						io.conectAdmin= "con";
						io.conectClient= "disc";
						socket.emit('redirect', '/admin');}
						if(result[0].types === "invite"){
						io.conectClient= "con";
						io.conectAdmin= "disc";
						socket.emit('redirect', '/consultation');
						}
					}else
					socket.emit('redirect', '/');
			  });
		});
    });
	
	socket.on('information', function (data) {
		var con = mysql.createConnection({
		  host: "localhost",
		  user: "root",
		  password: "",
		  database: "dbbiomedicale"
		});
		
		con.connect(function(err) {
		  if (err) throw err;
		  console.log("Connected!");
		  con.query("SELECT * FROM tblclient where nom = '" + data.nom + "'", 
		  //con.query("SELECT * FROM tblclient where nom = '" + data.nom + "' and prenom = '" + data.prenom + "' and dateDeNaissance = '" + data.naissance +"'", 
		  
		  //con.query("SELECT * FROM tbltest where idClient = '" + con.query("SELECT idClient FROM tblclient where nom = '" + data.nom + "' and prenom = '" + data.prenom + "' and dateDeNaissance = '" + data.naissance +"'";) +"'", 
		//con.query("SELECT * FROM tblclient where identifiant = '" + data.user + "' and passwd = '" + data.pw + "'", 
			
			 
			 function (err, result, fields) {
					if (err){
						//socket.emit('redirect', '/');
						throw err;
						console.log(result);
					}
					else{
					console.log('ici');
						socket.emit('recharger', {'idClient': result[0].idClient, 'types': result[0].types,
							'adresse': result[0].adresse, 'identifiant': result[0].identifiant, 'prenom': result[0].prenom,
						'nom': result[0].nom, 'dateDeNaissance': result[0].dateDeNaissance, 'passwd': result[0].passwd});
						console.log(result);
					}
					//else
						//socket.emit('recharger', 'Information client vide');
					//window.location.replace("admin.html");
			 });
		});
	});
	
	socket.on('synchroniser', function (data) {
        //message = ent.encode(message);
		//console.log(data.user, " " + data.pw);
		var con = mysql.createConnection({
		  host: "localhost",
		  user: "root",
		  password: "",
		  database: "dbbiomedicale"
		  
		 
		});
		
		
		con.connect(function(err) {
		  if (err) throw err;
		  console.log("Connected!");
		  con.query("SELECT idClient, types FROM tblclient where identifiant = '" + data.user + "' and passwd = '" + data.pw + "'", 
			  function (err, result, fields) {
					if (err){
						
						throw err;
						
					}
					
					if(result.length != 0){				
						
						if(result[0].types === "admin")
							socket.emit('redirect', '/admin');
						if(result[0].types === "invite")
						socket.emit('redirect', '/consultation');
					}else
					socket.emit('redirect', '/');
			  });
		});
    });
	
	socket.on('test', function (data) {
		console.log("socket2. allo");
	});
});

server.listen(8080);
