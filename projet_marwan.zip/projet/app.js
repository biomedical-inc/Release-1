var app = require('express')(),
    server = require('http').createServer(app),
    io = require('socket.io').listen(server),
    ent = require('ent'), // Permet de bloquer les caractères HTML (sécurité équivalente à htmlentities en PHP)
    fs = require('fs');

	app.use('/Styles', require('express').static('Styles'));
	app.use('/Images', require('express').static('Images'));
	app.use('/JavaScript', require('express').static('JavaScript'));

// Chargement des pages html
app.get('/', function (req, res) {
  res.sendfile(__dirname + '/index.html');
});

app.get('/admin', function (req, res) {
  res.sendfile(__dirname + '/admin.html');
});

app.get('/consultation', function (req, res) {
  res.sendfile(__dirname + '/consultation.html');
});

var mysql = require('mysql');

io.sockets.on('connection', function (socket) {

    socket.on('nouveau_client', function (data) {
        //message = ent.encode(message);
		//console.log(data.user, " " + data.pw);
		var con = mysql.createConnection({
		  host: "localhost",
		  user: "root",
		  password: "",
		  database: "bdd_biomedicale"
		  
		 
		});
		
		/*var connection;

		function handleDisconnect() {
		  connection = mysql.createConnection(con); // Recreate the connection, since
														  // the old one cannot be reused.

		  connection.connect(function(err) {              // The server is either down
			if(err) {                                     // or restarting (takes a while sometimes).
			  console.log('error when connecting to db:', err);
			  setTimeout(handleDisconnect, 2000); // We introduce a delay before attempting to reconnect,
			}                                     // to avoid a hot loop, and to allow our node script to
		  });                                     // process asynchronous requests in the meantime.
												  // If you're also serving http, display a 503 error.
		  connection.on('error', function(err) {
			console.log('db error', err);
			if(err.code === 'PROTOCOL_CONNECTION_LOST') { // Connection to the MySQL server is usually
			  handleDisconnect();                         // lost due to either server restart, or a
			} else {                                      // connnection idle timeout (the wait_timeout
			  throw err;                                  // server variable configures this)
			}
		  });
		}

		handleDisconnect();*/
		
		/*function handleDisconnect(){
			con.connect();
			console.log("Connected!");
		}*/
		con.connect(function(err) {
		  if (err) throw err;
		  console.log("Connected!");
		  con.query("SELECT idClient, type FROM tblclient where identifiant = '" + data.user + "' and passwd = '" + data.pw + "'", 
			  function (err, result, fields) {
					if (err){
						setTimeout(handleDisconnect, 2000);
						socket.emit('redirect', '/');
						//throw err;
						console.log(result);
					}
					if(result[0].type == "admin")
						socket.emit('redirect', '/admin');
					else
						socket.emit('redirect', '/consultation');
					//window.location.replace("admin.html");
			  });
		});
    });
	
	socket.on('test', function (data) {
		console.log("socket2. allo");
	});
});

server.listen(8080);
