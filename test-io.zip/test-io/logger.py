from socketIO_client import socketIO
import time
import ast
## Connection a la base de donnee
#!/usr/bin/env python3
import sqlite3

## Connection a la base de donnee
con = sqlite3.connect("devoir1.db")
cursor = con.cursor()
## Deleguees
def on_connect():
	print('connect')
def on_disconnect():
	print('disconnect')
def on_reconnect():
	print('reconnect')

## Code execute lorsqu'on a une nouvelle connection
user = ""
def nouveau_client(*args):
	user = ''.join(args)
	user[user.find('\'') : user.rfind('\'')]
	cursor.execute("Insert Into Presence(nom, date) Values ('" + user + "', date('now'));")
	con.commit()
## Code execute lorsqu'on a un nouveau message
def nouveau_message(*args):
	chaine = str(args)
	chaine = chaine[1 : len(chaine) - 2]
	a = ast.literal_eval(chaine)
	cursor.execute("Insert Into Messages(pseudo, message, date) Values ('" + a['pseudo'] + "', '" + a['message'] + "', date('now')));")
	con.commit()
## 'main'
socketIO = SocketIO('localhost', 8080)
socketIO.on('connect', on_connect)
socketIO.on('disconnect', on_disconnect)
socketIO.on('reconnect', on_reconnect)
socketIO.on('nouveau_client', nouveau_client)
socketIO.on('message', nouveau_message)
## Loop principal
socketIO.wait()
## On fait le menage
cursor.close()


## On fait le menage
con.close()
#cnx.close()
